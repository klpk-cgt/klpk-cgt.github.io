api接口调用成url


生成的网页https://raw.githubusercontent.com/klpk-cgt/klpk-cgt.github.io/main/price.txt
